import numpy as np
from sklearn.manifold import TSNE
from sklearn import decomposition
import matplotlib.pyplot as plt
from sklearn.neighbors import KernelDensity
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
# import seaborn as sns
# sns.set(style="ticks")

def plot_proj(feats_op, is_train, gt, classes, files, title_txt, fid):
    cols = ['r', 'g', 'b']
    plt.figure(fid)
    for cc in range(gt.max()+1):
        inds_tr = np.logical_and((gt==cc), is_train)
        inds_te = np.logical_and((gt==cc), np.logical_not(is_train))
        plt.plot(feats_op[inds_tr, 0], feats_op[inds_tr, 1], cols[cc]+'.', label=classes[cc])
        plt.plot(feats_op[inds_te, 0], feats_op[inds_te, 1], cols[cc]+'x')

    # plot the examples
    kde = KernelDensity()
    kde.fit(feats_op)
    wt = np.exp(kde.score_samples(feats_op))
    wt[np.where(is_train==1)[0]] = wt.max()+1  # set the train examples to high values

    num_test = 15
    te_inds = np.argsort(wt)[:num_test]
    te_inds = np.sort(te_inds)
    for ind in te_inds:
        print ind, files[ind]
        plt.plot(feats_op[ind, 0], feats_op[ind, 1], 'ko', markerfacecolor='none', ms=10, markeredgewidth=2)
        plt.gca().annotate(str(ind),xy=(feats_op[ind, 0], feats_op[ind, 1]+0.2))


    plt.legend()
    plt.title(title_txt)
    plt.axis('equal')
    plt.show()


plt.close('all')
da = np.load('oct_op.npz')
feats = da['feats']
gt = da['gt']
is_train = da['is_train']
classes = da['classes']
preds = np.argmax(da['preds'],1)
files = da['files']

# TSNE - can't separate train and test - need to embed all at once
#tsne = TSNE(n_components=2)
#feats_tsne = tsne.fit_transform(feats)
#plot_proj(feats_tsne, is_train, gt, classes, 'TSNE', 1)

# PCA
pca = decomposition.PCA(n_components=2)
pca.fit(feats[is_train==1, :], gt[is_train==1])
feats_pca = pca.transform(feats)
plot_proj(feats_pca, is_train, gt, classes, files, 'PCA', 2)

# LDA
lda = LinearDiscriminantAnalysis(n_components=2)
lda.fit(feats[is_train==1, :], gt[is_train==1])
feats_lda = lda.transform(feats)
plot_proj(feats_lda, is_train, gt, classes, files, 'LDA', 3)



